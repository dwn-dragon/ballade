;fileName:F:/Dev/Langs/cpp/ballade/build/Release/Ballade/core.zip
;machineType:default
;estimatedPrintTime:133
;volume:0.5425
;resin:normal
;weight:0.59675
;price:0.0179025
;layerHeight:1
;resolutionX:2560
;resolutionY:1600
;machineX:192
;machineY:120
;machineZ:200
;projectType:LCD_mirror
;transitionLayerCount:0
;transitionLayerType:0
;normalExposureTime:0.001
;bottomLayerExposureTime:60
;normalDropSpeed:150
;normalLayerLiftHeight:5
;zSlowUpDistance:0
;normalLayerLiftSpeed:65
;bottomLayerCount:2
;shrinkageX:100
;shrinkageY:100
;shrinkageZ:100
;mirror:1
;totalLayer:2
;bottomLayerLiftHeight:5
;bottomLayerLiftSpeed:65
;bottomLightOffTime:0
;lightOffTime:0
;bottomLayerDropSpeed:150
;edgeExposureMM:0
;edgeExposureTimeS:4
;bottomEdgeExposureMM:0
;bottomEdgeExposureTimeS:4
;START_GCODE_BEGIN
G21;
G90;
M106 S0;
G28 Z0;

;START_GCODE_END

;LAYER_START:0
;currPos:1
M6054 "1.png";show Image
G0 Z2.000000 F5.000000;
G0 Z1.000000 F150.000000;
G4 P0.000000;
M106 S255.000000;light on
G4 P60.000000;
M106 S0; light off

;LAYER_END

;LAYER_START:1
;currPos:2
M6054 "2.png";show Image
G0 Z3.000000 F5.000000;
G0 Z2.000000 F150.000000;
G4 P0.000000;
M106 S255.000000;light on
G4 P60.000000;
M106 S0; light off

;LAYER_END

;END_GCODE_BEGIN
M106 S0;
G1 Z{machine_height} F25;
M18;

;END_GCODE_END
